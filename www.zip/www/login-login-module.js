(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "34Y5":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "V6Ie");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "r67e");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modal-page/modal-page.component */ "ejfo");









let LoginPage = class LoginPage {
    constructor(router, loginGQL, modal) {
        this.router = router;
        this.loginGQL = loginGQL;
        this.modal = modal;
        // constructor(profileGQL: ProfileGQL , private authService: AuthService) {
        //   this.profile = profileGQL.watch(
        //   ).valueChanges.pipe(map(result => result.data.affiliateList.edges));
        // }
        this.is_TextFieldType = false;
        this.status = false;
    }
    ngOnInit() {
    }
    togglePasswordFieldType() {
        this.is_TextFieldType = !this.is_TextFieldType;
    }
    run_modal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modal.create({
                component: _modal_page_modal_page_component__WEBPACK_IMPORTED_MODULE_8__["ModalPageComponent"],
                cssClass: 'my-custom-class'
            });
            return yield modal.present();
        });
    }
    login() {
        this.loginGQL.mutate({
            username: this.user,
            password: this.pass
        }).subscribe(next => {
            if (next.data.tokenAuth.token != null) {
                let a = next.data.tokenAuth.token;
                let b = next.data.tokenAuth.user.loggedInUser.streamLink;
                localStorage.setItem(_constants__WEBPACK_IMPORTED_MODULE_4__["AUTHTOKEN"], a);
                localStorage.setItem(_constants__WEBPACK_IMPORTED_MODULE_4__["STREAMLINK"], b);
                if (b != "") {
                    this.router.navigate(['/home']);
                }
                else if (b == "") {
                    // this.status = true;
                    // let a = next.data.tokenAuth.token;
                    // localStorage.setItem(AUTHTOKEN,a);
                    this.run_modal();
                    // this.router.navigate(['/home']);
                }
            }
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: src_generated_graphql__WEBPACK_IMPORTED_MODULE_5__["LoginGQL"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ }),

/***/ "IhN0":
/*!******************************************************!*\
  !*** ./src/app/modal-page/modal-page.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC1wYWdlLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ "JF4m":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal-page/modal-page.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-card> -->\n  <ion-row>\n    <ion-label class=\"ion-text-center\">\n      log out\n    </ion-label>\n  </ion-row>\n<ion-row>\n  <ion-col class=\"ion-text-center\">\n  <ion-button color=\"danger\" (click)=\"logout()\">\n    Log out\n  </ion-button>\n  </ion-col>\n</ion-row>\n<!-- </ion-card>> -->\n");

/***/ }),

/***/ "V6Ie":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title class=\"ion-text-center\">login</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid style=\"height: 100%;\">\n    <ion-row style=\"display: flex; align-items: center; justify-content: center; height: 100%;\">\n      <ion-col size-md=\"10\" size-lg=\"5\" size-xl=\"3\">\n  <ion-card style=\"margin-top: -2em;\">\n    <ion-card-header>\n      <ion-title style=\"color: black;\" class=\"ion-text-center\">\n        Login Page\n      </ion-title>\n    </ion-card-header>\n    <ion-row class=\"ion-padding-top ion-padding-horizontal\">\n      <ion-col class=\"ion-text-right\">\n        <ion-label class=\"ion-padding-horizontal\"><strong>\n        نام کاربری</strong>\n      </ion-label>\n      </ion-col>\n    </ion-row>\n    <ion-item  class=\"ion-padding-horizontal\">\n      <ion-input  [(ngModel)]=\"user\" placeholder=\"Username\"></ion-input>\n    </ion-item>\n    <ion-row class=\"ion-padding-top ion-padding-horizontal\">\n      <ion-col class=\"ion-text-right\">\n        <ion-label class=\"ion-padding-horizontal\"><strong>\n        رمز عبور</strong>\n      </ion-label>\n      </ion-col>\n    </ion-row>\n    <!-- <ion-row class=\"ion-padding-horizontal\"> -->\n    <ion-item class=\"ion-padding-horizontal ion-padding-bottom\">\n      <ion-input [(ngModel)]=\"pass\" placeholder=\"Password\" [type]=\"is_TextFieldType ? 'text' : 'password'\"></ion-input>\n      <ion-icon style='color:#004a73'[name]=\"is_TextFieldType ? 'eye-off' : 'eye'\" (click)=\"togglePasswordFieldType()\"></ion-icon>\n    </ion-item>\n\n    <ion-row>\n      <ion-col class=\"ion-text-center\">\n        <ion-button (click)=\"login()\">\n          Enter\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-card>\n</ion-col>\n</ion-row>\n</ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "X3zk":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "euwS");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "34Y5");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "ejfo":
/*!****************************************************!*\
  !*** ./src/app/modal-page/modal-page.component.ts ***!
  \****************************************************/
/*! exports provided: ModalPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPageComponent", function() { return ModalPageComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_modal_page_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./modal-page.component.html */ "JF4m");
/* harmony import */ var _modal_page_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal-page.component.scss */ "IhN0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth.service */ "ccyI");






let ModalPageComponent = class ModalPageComponent {
    constructor(authservice, modalCtrl) {
        this.authservice = authservice;
        this.modalCtrl = modalCtrl;
    }
    ngOnInit() { }
    logout() {
        this.authservice.logout();
        this.modalCtrl.dismiss();
    }
};
ModalPageComponent.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
ModalPageComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-modal-page',
        template: _raw_loader_modal_page_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_modal_page_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ModalPageComponent);



/***/ }),

/***/ "euwS":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "34Y5");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "r67e":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-label {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUFDSiIsImZpbGUiOiJsb2dpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbGFiZWx7XG4gICAgY29sb3I6IGJsYWNrO1xufSJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map